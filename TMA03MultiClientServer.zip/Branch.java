/*
* J Haston, Personal Id U5032134
* Branch.java
* M874 02E TMA03
*/

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;

/*
* This class describes a video hire company branch, which is responsible
* for maintaining a stock of videos.
* The branch keeps multiple copies of each video.
*
* The Branch class has private instance variables describing:
*	the branch code, a String.
*	the branch name, a String.
*	a reference to a Hashtable, which holds the video details.
*
* The Hashtable keys hold references to the video code strings.
* The Hashtable values are references to the corresponding Video objects.
*/
public class Branch implements Serializable {

	private String branchCode;
	private String branchName;
	private Hashtable videoStockTable;

	//The Constructor...

	/*
	* Initialises the Branch code and name instance variables
	* with the supplied String arguments.
	* Creates a new Hashtable reference for storing the video stock.
	*/
	public Branch(String aBranchCode, String aBranchName) {
		branchCode = aBranchCode;
		branchName = aBranchName;
		videoStockTable = new Hashtable();
	}

	//Private Methods...

	/*
	* Returns a reference to the videoStockTable instance variable
	*/
	private Hashtable getVideoStockTable() {
		return videoStockTable;
	}

	/*
	* Returns a reference to the branchCode instance variable
	*/
	private String getBranchCode() {
		return branchCode;
	}

	/*
	* Returns a reference to the branchName instance variable
	*/
	private String getBranchName() {
		return branchName;
	}

	//Public Methods...

	/*
	* Returns the Branch code String.
	*/
	public String getCode() {
		return getBranchCode();
	}

	/*
	* Returns the Branch name String.
	*/
	public String getName() {
		return getBranchName();
	}

	/*
	* Returns an enumeration of the videos stocked at a branch.
	*/
	public Enumeration getVideoList() {
		return getVideoStockTable().elements();
	}

	/*
	* Adds a Video stock item to the Branch.
	* If it's code is not recognised the Video is added
	* to the Branch stock.
	* The Video's stock level is incremented in any case.
	*/
	public void addVideo(Video aVideo) {
		if (getVideoStockTable().containsKey(aVideo.getCode())) {
			((Video) getVideoStockTable().get(aVideo.getCode())).inc();
		}
		else {
			getVideoStockTable().put(aVideo.getCode(), aVideo);
			aVideo.inc();
		}
	}

	/*
	* Removes an existing Video stock item from the branch.
	* This removes all copies of the Video from the Branch.
	* Throws a NoSuchVideoException if the supplied argument
	* is not a recognised videoStocktable key.
	*/
	public void removeVideo(String aVideoCode) throws NoSuchVideoException {
		if (getVideoStockTable().containsKey (aVideoCode)) {
			getVideoStockTable().remove (aVideoCode);
		}
		else {
			throw new NoSuchVideoException(aVideoCode);
		}
	}

	/*
	* Returns an instance of the Video object identified by the
	* argument aVideoCode.
	* Throws a NoSuchVideoException if the supplied argument
	* is not recognised.
	* Throws a NoStockException if the Video has a stocklevel of zero.
	*/
	public Video getVideo(String aVideoCode) throws NoSuchVideoException, NoStockException {
		if (!getVideoStockTable().containsKey (aVideoCode)) {
			throw new NoSuchVideoException(aVideoCode);
		}
		else {
			Video thisVideo = (Video) getVideoStockTable().get(aVideoCode);
			if (thisVideo.getNumInStock()>0) {
				thisVideo.dec(); // video will be returned so decrement the stock level.
				return thisVideo;
			}
			throw new NoStockException(aVideoCode);
		}
	}

	/*
	* Returns a String representation of the Branch, consisting of
	* the Branch code and name followed by the details of each Video
	* held in stock.
	*/
	public String toString() {
		Enumeration e = getVideoList();
		String branchDetail=getBranchCode()+":"+getBranchName()+'\n';
		while (e.hasMoreElements())
			branchDetail=branchDetail+(e.nextElement())+'\n';
		return branchDetail;
	}
}