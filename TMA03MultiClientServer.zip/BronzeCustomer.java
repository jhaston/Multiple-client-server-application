/*
* J Haston, Personal Id U5032134
* BronzeCustomer.java
* M874 02E TMA03
*/

/*
* The BronzeCustomer class is a subclass of Customer and is
* responsible for implementing the superclass abstract methods
* addVideoLoan() and getDiscount().
*
* A BronzeCustomer cannot take duplicate loans of any video.
* The maximum number of different video loans permitted is
* defined by the MAX_VIDEOS_BRONZE constant.
*
* The loan discount for a BronzeCustomer is defined by the
* BRONZE_DISCOUNT constant.
*
* See the Customer class and the SysConstants public interface
* for more information.
*/

public class BronzeCustomer extends Customer {

	//Constructor...

	/*
	* Passes the account number and name arguments to
	* the superclass constructor to initialise the
	* corresponding instance variables. The superclass
	* constructor also creates a new videoLoanTable for
	* this BronzeCustomer.
	*/
	public BronzeCustomer(String anAccountNumber, String aName) {
		super(anAccountNumber, aName);
	}

	//Public Methods...

	/*
	* Returns a new Video loan subject to the current rules applied
	* to a BronzeCustomer.
	*
	* If the BronzeCustomer currently has the maximum number of loans
	* permitted the method throws a TooManyVideosException.
	*
	* If the BronzeCustomer currently has a copy of the Video on loan
	* the method throws a DuplicateVideoException.
	*/
	public void addVideoLoan(String aVideoCode) throws DuplicateVideoException, TooManyVideosException {
		if (this.getVideoTable().size() == MAX_VIDEOS_BRONZE) {
			throw new TooManyVideosException();
		}
		else {
			if (getVideoTable().containsKey (aVideoCode)) {
				throw new DuplicateVideoException(aVideoCode);
			}
			else {
				this.getVideoTable().put (aVideoCode, new Integer(1));
			}
		}
	}

	/*
	* Returns the discount value currently applied to a BronzeCustomer, an int.
	* BRONZE_DISCOUNT is a constant defined in SysConstants interface.
	*/
	public int getDiscount() {
		return BRONZE_DISCOUNT;
	}

}