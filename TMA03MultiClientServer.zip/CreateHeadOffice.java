/*
* J Haston, Personal Id U5032134
* CreateHeadOffice.java
* M874 02E TMA03
*/

import java.io.*;

/*
* The CreateHeadOffice class Creates a new HeadOffice instance
* from text files specified by the SysConstants interface.
* It then uses serialization to write the new HeadOffice object
* to the specified file.
*/
public class CreateHeadOffice {
   public static void main(String args[]) {
      HeadOffice newHeadOffice = new HeadOffice(100);
      System.out.println("Before saving HeadOffice..." + '\n' + '\n' + newHeadOffice);

      // Save the HeadOffice object...
      try {
         FileOutputStream fos = new FileOutputStream("HeadOffice.dat");
         ObjectOutputStream theObjectStream = new ObjectOutputStream(fos);
         theObjectStream.writeObject(newHeadOffice);
         theObjectStream.close();
         fos.close();
      }
      catch (IOException e) {
         System.out.println("\nIOException on attempt to open : " + e.getMessage());
      }
   }
}