/*
* J Haston, Personal Id U5032134
* Customer.java
* M874 02E TMA03
*/

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Enumeration;

/*
* The Customer class is responsible for maintaining a list of the
* videos currently on hire to a customer of the video hire company.
* There are two abstract methods which must be implemented by the
* different types of Customer subclass.
*
* The Customer class has private instance variables describing:
*	-the customer's account number, a String.
*	-the customer's name, a String.
*	-a reference to a Hashtable, which stores the videos currently
*	 on loan to the customer.
*
* The Hashtable keys hold references to the video code strings.
* The Hashtable values are Integers representing the number of
* copies of each video currently on loan to a customer.
*/
public abstract class Customer implements Serializable, SysConstants {

	private String accountNumber;
	private String customerName;
	private Hashtable videoLoanTable;

	//The Constructor...

	/*
	* Initialises the Customer account number and name instance variables.
	* Creates a new Hashtable reference for storing a count of the different
	* Videos on loan.
	*/
	public Customer(String anAccountNumber, String aName) {
		accountNumber = anAccountNumber;
		customerName = aName;
		videoLoanTable = new Hashtable();
	}

	//Private Methods ...

	/*
	* Returns a reference to the accountNumber instance variable.
	*/

	private String getAccountNumber() {
		return accountNumber;
	}

	/*
	* Returns a reference to the customerName instance variable.
	*/

	private String getCustomerName() {
		return customerName;
	}

	/*
	* Returns a reference to the videoLoanTable instance variable.
	*/

	private Hashtable getVideoLoanTable() {
		return videoLoanTable;
	}

	//Public Methods ...

	/*
	* Returns the String representation of the Customer account number .
	*/
	public String getAccountNum() {
		return getAccountNumber();
	}

	/*
	* Returns the Customer name String.
	*/
	public String getName() {
		return getCustomerName();
	}

	/*
	* Returns a reference to the Customer's current list of Video loans.
	* The keys are video code Strings and the values are the corresponding
	* numbers of video copies on loan, represented by Integers.
	*/
	public Hashtable getVideoTable() {
		return getVideoLoanTable();
	}

	/*
	* This abstract method must be implemented by the Customer subclasses.
	* Each subclass may add a new Video loan in accordance with
	* special rules for that type of Customer.
	*/
	public abstract void addVideoLoan(String aVideoCode) throws Exception;

	/*
	* This abstract method must be implemented by the Customer subclasses.
	* Each subclass may apply a different level of discount on
	* new Video loans.
	*/
	public abstract int getDiscount();

	/*
	* Removes an entry from the Customer's list of
	* current Video loans.
	* Throws a NoSuchVideoException if the supplied argument
	* is not a recognised video code.
	*/
	public void removeVideo(String aVideoCode) throws NoSuchVideoException {
		if (!getVideoLoanTable().containsKey (aVideoCode))
			throw new NoSuchVideoException(aVideoCode);
		else
			getVideoLoanTable().remove (aVideoCode);
	}

	/*
	* Returns a count of the total number of Videos currently
	* on loan to the Customer.
	*/
	public int getNumVideosOnLoan() {
		int numberOfVideosOnLoan = 0;
		Enumeration e = getVideoLoanTable().elements();
		while (e.hasMoreElements())
			numberOfVideosOnLoan+=((Integer) e.nextElement()).intValue();
		return numberOfVideosOnLoan;
	}

	/*
	* Returns an Enumeration of the Customer's video loans (video codes).
	*/
	public Enumeration getVideoRefList() {
		return getVideoLoanTable().keys();
	}

	/*
	* Returns a String representation of the Customer consisting of:
	* 	-The Customer account number and name followed by a character
	* 	 denoting the Customer type.
	* 	- A listing of the Video loans and the corresponding number
	* 	 of copies for each Video on loan to the Customer.
	*/
	public String toString() {
		String customerDetail=getAccountNum() + ":" + getName() + ":" + getClass().getName().charAt(0) + '\n';
		Enumeration e = getVideoRefList();
		while (e.hasMoreElements()) {
			Object thisElement = (e.nextElement());
			customerDetail=customerDetail+(thisElement) + "-" +
			(Integer) getVideoTable().get(thisElement) + '\n';
		}
		return customerDetail;
	}
}