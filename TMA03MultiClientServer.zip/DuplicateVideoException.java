/*
* J Haston, Personal Id U5032134
* DuplicateVideoException.java
* M874 02E TMA03
*/

/*
* Constructs a DuplicateVideoException with the specified detail message.
*/
public class DuplicateVideoException extends Exception {
	public DuplicateVideoException(String aVideoCode) {
		super("DuplicateVideoException : "+ aVideoCode+" already on loan");
	}
}