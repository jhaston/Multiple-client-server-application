/*
* J Haston, Personal Id U5032134
* GoldCustomer.java
* M874 02E TMA03
*/

/*
* The GoldCustomer class is a subclass of Customer and is
* responsible for implementing the superclass abstract methods
* addVideoLoan() and getDiscount().
*
* A GoldCustomer can take duplicate loans of any video.
* The maximum number of different video loans permitted is
* defined by the MAX_VIDEOS_GOLD constant.
*
* The loan discount for a GoldCustomer is defined by the
* GOLD_DISCOUNT constant.
*
* See the Customer class and the SysConstants public interface
* for more information.
*/

public class GoldCustomer extends Customer {

	//The Constructor...

	/*
	* Passes the account number and name arguments to
	* the superclass constructor to initialise the
	* corresponding instance variables. The superclass
	* constructor also creates a new videoLoanTable for
	* this GoldCustomer.
	*/
	public GoldCustomer(String anAccountNumber, String aName) {
		super(anAccountNumber, aName);
	}

	//Public Methods...

	/*
	* Returns a new Video loan subject to the current rules applied
	* to a GoldCustomer.
	*
	* If the GoldCustomer currently has the maximum number of loans
	* permitted the method throws a TooManyVideosException.
	*/

	public void addVideoLoan(String aVideoCode) throws TooManyVideosException {

		if (getVideoTable().containsKey (aVideoCode)) {
			int i = ((Integer) getVideoTable().get(aVideoCode)).intValue();
			this.getVideoTable().put (aVideoCode, new Integer(++i));
		}
		else {
			if (this.getVideoTable().size() == MAX_VIDEOS_GOLD) {
						throw new TooManyVideosException();
			}
			else {
				this.getVideoTable().put (aVideoCode, new Integer(1));
			}
		}
	}

	/*public void addVideoLoan(String aVideoCode) throws TooManyVideosException {
		if (this.getVideoTable().size() == MAX_VIDEOS_GOLD) {
			throw new TooManyVideosException();
		}
		else {
			if (getVideoTable().containsKey (aVideoCode)) {
				int i = ((Integer) getVideoTable().get(aVideoCode)).intValue();
				this.getVideoTable().put (aVideoCode, new Integer(++i));
			}
			else {
				this.getVideoTable().put (aVideoCode, new Integer(1));
			}
		}
	}*/

	/*
	* Returns the discount value currently applied to a GoldCustomer, an int.
	* GOLD_DISCOUNT is a constant defined in SysConstants interface.
	*/
	public int getDiscount() {
		return GOLD_DISCOUNT;
	}

}