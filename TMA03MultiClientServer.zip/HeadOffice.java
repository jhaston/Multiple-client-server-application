/*
* J Haston, Personal Id U5032134
* HeadOffice.java
* M874 02E TMA03
*/

import java.io.*;
import java.util.Vector;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.StringTokenizer;

/*
* The HeadOffice class is responsible for maintaining registers
* of it's branches and customers. It also defines the stock level
* of videos held by each branch and is responsible for allocating
* videos to the different branches.
*
* The HeadOffice class has the following private instance variables:
*	- branchRegister, which references  a Vector containing
*	  instances of the branches controlled by a HeadOffice.
*
*	- customerRegister, which references  a Vector containing
*	  instances of the customers serviced by a video company.
*/
public class HeadOffice implements SysConstants, Serializable {
	private Vector branchRegister = new Vector();
	private Vector customerRegister = new Vector();

	//The Constructor...

	/*
	* Initialises a new instance of HeadOffice by creating a new
	* branch list, allocating videos to the different branches
	* and creating a new customer list.
	*
	* The int argument specifies the number of copies of each
	* video to be held by the branches.
	*/
	public HeadOffice(int aStocklevel) {
		createBranchList();
		allocateVideosToBranches(aStocklevel);
		createCustomerList();
	}

	//Private Methods...

	/*
	* Returns a reference to the branchRegister instance variable.
	*/
	private Vector getBranchRegister() {
		return branchRegister;
	}

	/*
	* Returns a reference to the customerRegister instance variable.
	*/
	private Vector getCustomerRegister() {
		return customerRegister;
	}

	/*
	* Reads a text file containing the details of each branch
	* controlled by a HeadOffice and uses each line of text to
	* create a new Branch instance. Adds a reference to each new
	* Branch instance to the branch register.
	*
	* The text file used to create the branch list is specified
	* by the BRANCH_DATA_BASE constant (see the SysConstants
	* interface for further information).
	*/
	private void createBranchList() {
		try{
			FileInputStream fis = new FileInputStream(BRANCH_DATA_BASE);
			BufferedReader branchData = new BufferedReader(new InputStreamReader(fis));
			String thisBranch;
			while ((thisBranch = branchData.readLine())!=null) {
				StringTokenizer st = new StringTokenizer(thisBranch, "*");
				String branchCode = st.nextToken();
				if (branchCode.equals("STOP")) {
					break;// ends process of creating/adding new branches.
				}
				String branchName = st.nextToken();
				Branch newBranch = new Branch(branchCode, branchName);
				addBranch(newBranch);
		 	}
         	branchData.close();
         	fis.close();
		}
	 	catch(IOException i) {
			System.out.println("I/O error : " + i.getMessage());
		}
	}

	/*
	* Reads a text file containing the details of each video to be
	* allocated to the branches and uses each line of text to create
	* a new Video instance. Associates  new Video instances with the
	* Branches.
	*
	* The text file containing each video's details is specified by
	* the VIDEO_DATA_BASE constant (see the SysConstants interface).
	*/
	private void allocateVideosToBranches(int numCopies) {
		try{
			String thisVideo;
			Enumeration e = getBranchList();
			FileInputStream fis = new FileInputStream(VIDEO_DATA_BASE);
			BufferedReader videoData = new BufferedReader(new InputStreamReader(fis));
			while (e.hasMoreElements()) {
				String branchCode = ((Branch) e.nextElement()).getCode();
				while ((thisVideo = videoData.readLine())!=null) {
					StringTokenizer st = new StringTokenizer(thisVideo, "*");
					String videoCode = st.nextToken();
					if (videoCode.equals("BREAK")) {
						break;// ends process of creating/adding new videos to the current Branch.
					}
					String videoTitle = st.nextToken();
					String videoRentalCost = st.nextToken();
					String videoPreviewText = st.nextToken();
					Video newVideo = new Video(videoCode, videoTitle, videoRentalCost, videoPreviewText);
					for(int i = 0; i<numCopies; i++) {
						getBranch(branchCode).addVideo(newVideo);
					}
				}
			}
			videoData.close();
			fis.close();
		}
		catch(IOException i) {
			System.out.println("I/O error : " + i.getMessage());
		}
		catch(NoSuchBranchException nsb) {
			System.out.println(nsb.getMessage());
		}
	}

	/*
	* Reads a text file containing the details of each customer
	* seviced by a HeadOffice and uses each line of text to
	* create a new Customer instance. Adds a reference to each new
	* Customer instance to the branch register.
	*
	* The text file used to create the branch list is specified
	* by the BRANCH_DATA_BASE constant (see the SysConstants
	* interface for further information).
	*
	* The text file used to create the customer list is specified by the
	* CUSTOMER_DATA_BASE constant (see the SysConstants interface).
	*/
	private void createCustomerList() {
		try{
			String thisCustomer;
			Customer newCustomer = null;
			FileInputStream fis = new FileInputStream(CUSTOMER_DATA_BASE);
			BufferedReader customerData = new BufferedReader(new InputStreamReader(fis));
			while ((thisCustomer = customerData.readLine())!=null) {
				StringTokenizer st = new StringTokenizer(thisCustomer, "*");
				String customerAccountNumber = st.nextToken();
				if (customerAccountNumber.equals("STOP")) {
					break;// ends process of creating/adding new customers.
				}
				String customerName = st.nextToken();
				st.nextToken();// this token contains a branch code and is discarded.
				String customerType = st.nextToken();
				if (customerType.equals("G")) {
					newCustomer = new GoldCustomer(customerAccountNumber, customerName);
				}
				else {
					if (customerType.equals("B")) {
						newCustomer = new BronzeCustomer(customerAccountNumber, customerName);
					}
				}
				if (newCustomer != null) {
					registerCustomer(newCustomer);// if the customer type was recognised.
				}
			}
			customerData.close();
			fis.close();
		}
		catch(IOException i) {
			System.out.println("I/O error : " + i.getMessage());
		}
	}

	//Public Methods...

	/*
	* Returns an Enumeration of the branches in the branch register.
	*/
	public Enumeration getBranchList() {
		return getBranchRegister().elements();
	}

	/*
	* Returns an Enumeration of the customers in the customer register.
	*/
	public Enumeration getCustomerList() {
		return getCustomerRegister().elements();
	}

	/*
	* Adds a new Branch object reference to the branch register.
	*/
	public void addBranch(Branch aBranch) {
		getBranchRegister().addElement(aBranch);
	}

	/*
	* Returns a reference to a Branch instance associated with
	* the HeadOffice. If a Branch with the specified branch code
	* is not found the method throws a NoSuchBranchException.
	*/
	public Branch getBranch(String aBranchCode) throws NoSuchBranchException {
		for (int i = 0; i < getBranchRegister().size(); i++) {
			if (((Branch) getBranchRegister().elementAt(i)).getCode().equals(aBranchCode)) {
				return ((Branch) getBranchRegister().elementAt(i));
			}
		}
		throw new NoSuchBranchException(aBranchCode);
	}

	/*
	* Adds a new Customer object reference to the customer register.
	*/
	public void registerCustomer(Customer aCustomer) {
		getCustomerRegister().addElement(aCustomer);
	}

	/*
	* Removes a Customer object reference from the customer register.
	* If a Customer with the specified account number is not found
	* a NoSuchCustomerException will be thrown (See the getCustomer()
	* method).
	*/
	public void removeCustomer(String anAccNumber) throws NoSuchCustomerException {
		getCustomerRegister().removeElement(getCustomer(anAccNumber));
	}

	/*
	* Returns a reference to a Customer instance associated with
	* the HeadOffice. If a Customer with the specified account number
	* is not found the method throws a NoSuchCustomerException.
	*/
	public Customer getCustomer(String anAccNumber) throws NoSuchCustomerException {
		Enumeration e = getCustomerList();
		while (e.hasMoreElements()) {
			Customer thisCustomer = (Customer) e.nextElement();
			if (thisCustomer.getAccountNum().equals(anAccNumber)) {
				return thisCustomer;
			}
		}
		throw new NoSuchCustomerException(anAccNumber);
	}

	/*
	* Returns a reference to a Video object.
	* An exhaustive search through all the Branches associated with
	* the HeadOffice is made. If no matching Video is found the method
	* returns a null value.
	*
	* It should be noted that this method calls the getVideo() method
	* from the Branch class. Any exception thrown by the branch class
	* getVideo() method will be caught and the search will continue to
	* the next Branch in the list.
	*/
	public Video getVideo(String aVideoCode) {
		Enumeration e = getBranchList();
		while (e.hasMoreElements()) {
			Branch thisBranch = (Branch) e.nextElement();
			try {
				return (thisBranch.getVideo(aVideoCode));
			}
			catch (NoSuchVideoException nsv) {
				continue;
			}
			catch (NoStockException ns) {
				continue;
			}
		}
		return null;
	}

	/*
	* Adds a new video loan for a Customer. It takes two
	* arguments; a Customer and a Video.
	*
	* If the Video argument is passed from the HeadOffice.getVideo(String)
	* method it could be a null value.
	*
	* Subject to the Customer type a TooManyVideosException or a
	* DuplicateVideoException may be thrown (See the Customer classes for
	* more detail).
	*/
	public void loanVideo(Customer aCustomer, Video aVideo) throws Exception {
			if (aVideo != null) {
				aCustomer.addVideoLoan((String) aVideo.getCode());
			}
	}

	/*
	* Returns the current total value of all loans held by the Customer.
	*
	* The String argument must be a valid Customer account number otherwise
	* a NoSuchCustomerException will be thrown.
	*/
	public int getLoanValue(String anAccNumber) throws NoSuchCustomerException {
		int loanValue = 0;
		Customer thisCustomer = getCustomer(anAccNumber);
		int customerDiscount = thisCustomer.getDiscount();
		Hashtable thisLoanTable = thisCustomer.getVideoTable();
		Enumeration e = thisCustomer.getVideoRefList();
		while (e.hasMoreElements()) {
			String videoCode = ((String) e.nextElement());
			int videoQuantity = ((Integer) thisLoanTable.get(videoCode)).intValue();
			int videoRentalCost = Integer.decode((getVideo(videoCode).getRentalCost())).intValue();
			loanValue = loanValue + ((videoRentalCost - customerDiscount) * videoQuantity);
		}
		return loanValue;
	}

	/*
	* Returns the specified Customer's current Video loan list in
	* a Vector. Each element of the returned Vector contains a String
	* consisting of a Video title followed by the number of copies
	* currently on loan.
	*
	* If the Customer has no current loans then an empty Vector is
	* returned.
	*/
	public Vector getLoanList(Customer aCustomer) {
		Vector loanList = new Vector();
		Hashtable thisLoanTable = aCustomer.getVideoTable();
		Enumeration e = aCustomer.getVideoRefList();
		while (e.hasMoreElements()) {
			String videoCode = ((String) e.nextElement());

			int videoQuantity = ((Integer) thisLoanTable.get(videoCode)).intValue();
			String videoTitle = (getVideo(videoCode).getTitle());
			loanList.addElement(videoTitle + ":" + videoQuantity);
		}
		return loanList;
	}

	/*
	* Returns a String representation of the HeadOffice consisting of:
	*	- A listing of all associated Branches (including their details
	*	  and stock) followed by a listing of all associated Customers
	*	  (including their  details and loans).
	*/
	public String toString() {
		String headOfficeDetail = "--- BRANCH DETAILS ---";//+'\n';
		Enumeration e1 = getBranchList();
		while (e1.hasMoreElements()) {
			headOfficeDetail = headOfficeDetail + (Branch) e1.nextElement() + '\n';
		}
		headOfficeDetail = headOfficeDetail +  "--- CUSTOMER DETAILS ---"+'\n';
		Enumeration e2 = getCustomerList();
		while (e2.hasMoreElements()) {
			headOfficeDetail = headOfficeDetail + (Customer) e2.nextElement();
		}
		return headOfficeDetail;
	}

	/*
	* Processes transaction requests received from the VHCServer and
	* VHCClientConnection classes. Each transaction uses the methods
	* contained in the HeadOffice class to gather information for a
	* client. In the case where a new loan is requested the customer's
	* loan information may be updated.
	*
	* This method is synchronized so that it can be used to serve a
	* multi-client server application using the VHCClientConnection class.
	*
	* The VHCServer class may be used to serve sequential clients.
	*
	* The content of the String returned by this method depends on the
	* specific transaction request.
	*
	* "Populate branchlist" - results in a list of Branches being returned.
	* "Populate videolist" -- results in the list of videos held by the
	*                         specified branch being returned.
	* "Preview video" ------- returns a short preview for the specified video.
	* "Populate loanlist" --- returns the list of videos currently on loan
	*                         to the specified customer.
	* "Add new loan" -------- Creates a new loan for the specified customer,
	*                         subject to the membership conditions, and
	*                         returns a confirmation message.
	*/
	public synchronized String processTransaction(Customer thisCustomer, String input) {
		String output = null;

		if (input.equals("Populate branchlist")) {
			output = "";
			Enumeration e = getBranchList();
			while (e.hasMoreElements()) {
				Branch thisBranch = (Branch) e.nextElement();
				output = output + thisBranch.getCode() + ":" + thisBranch.getName() + '\n';
			}
			output = output + "EndOfBranchList";
		}

		if (input.startsWith("Populate videolist")) {
			output = "";
			String branchCode = input.substring(18,24);
			try {
				getBranch(branchCode);
				Enumeration e = getBranch(branchCode).getVideoList();
				while (e.hasMoreElements()) {
					Video thisVideo = (Video) e.nextElement();
					output = output + thisVideo.getCode() + ":" + thisVideo.getTitle() + '\n';
				}
			}
			catch (NoSuchBranchException e) {
				//do nothing
			}
			output = output + "EndOfVideoList";
		}

		if (input.startsWith("Preview video")) {
			output = "";
			String videoCode = input.substring(13,17);
			Video thisVideo = getVideo(videoCode);
			if (thisVideo != null) {
				output = thisVideo.getPreview();
			}
			else {
				output = " Please select a video.";
			}
		}

		if (input.equals("Populate loanlist")) {
			output = "";
			Vector v = getLoanList(thisCustomer);
			Enumeration e = v.elements();
			while (e.hasMoreElements()) {
				output = output + e.nextElement() + '\n';
			}
			output = output + "EndOfLoanList";
		}

		if (input.startsWith("Add new loan")) {
			int newLoanEndIndex = input.length();
			String videoCode = input.substring(12,16);
			String videoTitle = input.substring(17,newLoanEndIndex);
			try {
				loanVideo(thisCustomer, getVideo(videoCode));
				output = " Your order for " + videoTitle + " was successfully processed.";
			}
			catch(Exception e) {
				if (e.getMessage().startsWith("TooManyVideosException")) {
					output = " Your order for " + videoTitle + " was not completed." +
					" Your maximum number of videos are already on loan.";
				}
				if (e.getMessage().startsWith("DuplicateVideoException")) {
					output = " Your order for " + videoTitle + " was not completed." +
					" Duplicate video loans are not permitted.";
				}
			}
		}
		return output;
	}
 }
