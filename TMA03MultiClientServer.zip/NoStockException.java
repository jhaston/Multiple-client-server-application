/*
* J Haston, Personal Id U5032134
* NoStockException.java
* M874 02E TMA03
*/

/*
* Constructs a NoStockException with the specified detail message.
*/
public class NoStockException extends Exception {
	public NoStockException(String aVideoCode) {
		super("NoStockException : Video is out of stock : "+ aVideoCode);
	}
}