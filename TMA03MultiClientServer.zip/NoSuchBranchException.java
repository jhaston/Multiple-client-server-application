/*
* J Haston, Personal Id U5032134
* NoSuchBranchException.java
* M874 02E TMA03
*/

/*
* Constructs a NoSuchBranchException with the specified detail message.
*/
public class NoSuchBranchException extends Exception {
	public NoSuchBranchException(String aBranchCode) {
		super("NoSuchBranchException : No branch with code number : "+ aBranchCode);
	}
}