/*
* J Haston, Personal Id U5032134
* NoSuchCustomerException.java
* M874 02E TMA03
*/

/*
* Constructs a NoSuchCustomerException with the specified detail message.
*/
public class NoSuchCustomerException extends Exception {
	public NoSuchCustomerException(String anAccNumber) {
		super("NoSuchCustomerException : No customer with code number : "+ anAccNumber);
	}
}