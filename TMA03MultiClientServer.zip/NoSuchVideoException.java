/*
* J Haston, Personal Id U5032134
* NoSuchVideoException.java
* M874 02E TMA03
*/

/*
* Constructs a NoSuchVideoException with the specified detail message.
*/
public class NoSuchVideoException extends Exception {
	public NoSuchVideoException(String aVideoCode) {
		super("NoSuchVideoException : No video with code number : "+ aVideoCode);
	}
}