/*
* J Haston, Personal Id U5032134
* ReadHeadOffice.java
* M874 02E TMA03
*/

import java.io.*;

/*
* The ReadHeadOffice class de-serializes a HeadOffice object
* from the specified file.
*
* This class has a single public method which returns the
* HeadOffice data.
*/
public class ReadHeadOffice {

	private HeadOffice thisHeadOffice;

	//The Constructor...

	/*
	* De-serializes a HeadOffice object from the specified file.
	*/
	public ReadHeadOffice() {
		try {
			System.out.println("Initialising HeadOffice data...");
			FileInputStream fis = new FileInputStream("HeadOffice.dat");
			ObjectInputStream theObjectStream = new ObjectInputStream(fis);
			thisHeadOffice = (HeadOffice)theObjectStream.readObject();
			theObjectStream.close();
			fis.close();
		}
		catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
		catch (NotSerializableException e) {
			System.out.println(e.getMessage());
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
		}
		catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	/*
	* Returns a reference to the current HeadOffice data.
	*/
	private HeadOffice getHeadOfficeData() {
		return thisHeadOffice;
	}

	/*
	* Returns the current HeadOffice data.
	*/
	public HeadOffice getCurrentData() {
		return getHeadOfficeData();
	}
}