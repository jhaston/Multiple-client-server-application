/*
* J Haston, Personal Id U5032134
* SysConstants.java
* M874 02E TMA03
*/

/*
* Specifies current system constants for a video hire business.
*/
public interface SysConstants {
	//These are the text files used to construct a HeadOffice Class instance.
	public static final String BRANCH_DATA_BASE = "BranchFile.txt";
	public static final String VIDEO_DATA_BASE = "VideoFile.txt";
	public static final String CUSTOMER_DATA_BASE = "CustomerFile.txt";
	// These are the maximum number of videos that can be hired.
	public static final int MAX_VIDEOS_GOLD = 5;
	public static final int MAX_VIDEOS_BRONZE = 2;
	// The current customer discounts, (in pence per video).
	public static final int GOLD_DISCOUNT = 50;
	public static final int BRONZE_DISCOUNT = 15;
}