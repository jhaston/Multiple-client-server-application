/*
* J Haston, Personal Id U5032134
* TooManyVideosException.java
* M874 02E TMA03
*/

/*
* Constructs a TooManyVideosException with the specified detail message.
*/
public class TooManyVideosException extends Exception {
	public TooManyVideosException() {
		super("TooManyVideosException : Maximum number of different videos already on loan");
	}
}