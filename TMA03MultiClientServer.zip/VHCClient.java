/*
* J Haston, Personal Id U5032134
* VHCClient.java
* M874 02E TMA03
*/

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.Enumeration;

/*
* The VHCClient class provides a GUI for customers who wish
* to view and order videos through a network connection.
*
* Two different window layouts are presented to the user of the GUI.
* - a LOGIN WINDOW, which allows the user to enter a password and
*   connect with a VHC server.
* - a TRANSACTION WINDOW, which allows the user to view lists of the
*   videos held at selected VHC stores, preview videos, reserve videos
*   and order videos through the network connection. The transaction
*   window also provides the user with an up-to-date listing of the
*   videos they currently have on loan.
*/
public class VHCClient extends Frame implements WindowListener, ActionListener, ItemListener, FocusListener {

	private Panel topPanel;
	private Panel middlePanel;
	private Panel bottomPanel;
	private Panel bottomLeftPanel;
	private Panel bottomRightPanel;
	//
	private TextField wellcomeMessage;
	private TextField loginPrompt;
	private TextField loginTextField;
	private TextArea messageArea;
	//
	private Button loginButton;
	private Button previewVideoButton;
	private Button reserveVideoButton;
	private Button sendOrderButton;
	private Button closeTransactionViewButton;
	//
	private List branchList;
	private List videoList;
	private List currentLoanList;
	private List reservedVideoList;
	//
	private Socket socket;
	//
	private PrintWriter output;
	private BufferedReader input;
	//
	private String fromServer;
	private String host;
	//
	private boolean connected;
	private boolean loggedIn;
	//
	private Vector currentReservations;
	//
	private Dimension frameSize;
	//
	private WindowEvent closeWindow = null;
	//
	private static int port;
	//

	//The Main Method...

	/*
	* Takes an int argument for use as a Server port number and
	* creates a new VHCClient instance.
	*
	* If no argument is supplied or if the argument is otherwise invalid
	* the default port number (6001) is used.
	*/
	public static void main(String[] args) {
		try {
			port = Integer.parseInt(args[0]);
			if (!(port>1024)) {
				port = 6001;
			}
		}
		catch (Exception e) {
			port = 6001;
		}
		new VHCClient("VHC Online Booking Service");
	}

	//The Constructor...

	/*
	* Initialises a new instance of VHCClient.
	*/
  	public VHCClient(String title) {
		super(title); //constucts top level frame

		addWindowListener(this); // used for main window events.

		//Initialize the non-visual instance variables.
		socket = null;
		output = null;
		input = null;
		fromServer = "";
		host = "127.0.0.1";
		connected = false;
		loggedIn = false;
		currentReservations = new Vector();
		setLayout(new BorderLayout());
		frameSize = new Dimension();
		closeWindow = new WindowEvent(this, 1);

		//Set the Frame's properties
		setResizable(false);
		setLocation(50, 50);
		setVisible(true);
		//
		initializeLoginView();
  	}

	/*
	* Closes resources used by this client.
	*
	* Does some extra cleaning-up.
	*/
  	public void closeConnection() {
		if (connected) {
			try {
				output.close();
				input.close();
				socket.close();
				connected = false;
				loggedIn = false;
				this.loginTextField.requestFocus(); //only useful for the login view.
				loginTextField.selectAll(); //the text field might not have lost focus.
			}
			catch(IOException iExc){
			}
		}
	}

	/*
	* Adds visual objects required for the client login view.
	*/
	public void initializeLoginView() {
		this.removeAll();
		addLoginWindowPanels();
		addWelcomeMessage();
		addLoginPrompt();
		addLoginTextField("*******");
		addLoginButton();
		addMessageArea(middlePanel, " - Message Window -");
		this.frameSize.setSize(475,195);
		this.setSize(frameSize);
		this.validate();
		loginTextField.requestFocus();
	}

	/*
	* Creates the login view panels.
	*/
	public void addLoginWindowPanels() {
		topPanel = new Panel(new BorderLayout());
		middlePanel = new Panel(new BorderLayout());
		this.add(BorderLayout.NORTH, topPanel);
		this.add(BorderLayout.CENTER, middlePanel);
	}

	/*
	* Creates the login view wellcome message and adds it
	* to the top panel.
	*/
	public void addWelcomeMessage() {
		wellcomeMessage = new TextField("            >>>>> WELCOME TO THE VHC ON-LINE VIDEO HIRE SYSTEM <<<<<", 55);
		wellcomeMessage.setBackground(Color.yellow);
		wellcomeMessage.setEditable(false);
		topPanel.add(BorderLayout.NORTH, wellcomeMessage);
	}

	/*
	* Creates the login view prompt message and adds it
	* to the top panel.
	*/
	public void addLoginPrompt() {
		loginPrompt = new TextField(" Please enter your password (Case sensitive) ...");
		loginPrompt.setBackground(Color.yellow);
		loginPrompt.setEditable(false);
		topPanel.add(BorderLayout.WEST, loginPrompt);
	}

	/*
	* Creates the login view password field and adds it
	* to the top panel.
	*/
	public void addLoginTextField(String text) {
		loginTextField = new TextField(text);
		loginTextField.setBackground(Color.yellow);
		loginTextField.setEditable(true);
		loginTextField.setEchoChar('*');
		topPanel.add(BorderLayout.CENTER, loginTextField);
		loginTextField.addActionListener(this);
		loginTextField.addFocusListener(this);
	}

	/*
	* Creates the login view 'connect' button and adds it
	* to the top panel.
	*/
	public void addLoginButton() {
		loginButton = new Button("<<< Connect to the server >>>");
		loginButton.setBackground(Color.yellow);
		topPanel.add(BorderLayout.SOUTH, loginButton);
		loginButton.addActionListener(this);
	}

	/*
	* Creates the message area used in both the login view and the
	* transaction view. The panel containing this message area is
	* supplied as an argument, as is the initial display String.
	*/
	public void addMessageArea(Panel aPanel, String defaultString) {
		messageArea = new TextArea(defaultString, 5, 80, 1);
		messageArea.setBackground(Color.lightGray);
		messageArea.setEditable(false);
		aPanel.add(BorderLayout.NORTH, messageArea);
	}

	/*
	* Attempts to connect to the VHC service through a socket provided
	* on the VHC host computer. The customer's password is provided as
	* an argument (from the login view password field).
	*/
	public void clientLogin(String password) {
		if (!connected) {
			messageArea.setText("Connecting...");
					try{
						Thread.sleep(500);
					}
					catch(Exception e) {
					}
			try {
				socket = new Socket(host, port);
				output = new PrintWriter(socket.getOutputStream(), true);
				input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				connected = true;
			}
			catch (UnknownHostException e) {
				closeConnection();
			}
			catch (IOException e1) {
				closeConnection();
			}
		}
		try {
			if (connected) {
				messageArea.setText("Validating password...");
				output.println(password);
				fromServer = input.readLine();

				if (fromServer.equals("Login Accepted")) {
					messageArea.setText(" Logged in to host: " + host + "... Starting viewer...");
					loggedIn = true;

					try{
						Thread.sleep(1000);
					}
					catch(Exception e) {
					}
					initializeTransactionView();
				}
				else {
					//Close connection if password is not recognised
					try{
						Thread.sleep(750);
					}
					catch(Exception e) {
					}
					messageArea.setText(" The password was not recognised. Please try again.");
					closeConnection();
				}
			}
		}
		catch(IOException iExc){
			closeConnection();
		}
	}

	/*
	* Adds visual objects required for the client transaction view.
	*/
	public void initializeTransactionView() {
		this.removeAll();
		addTransactionWindowPanels();
		addBranchList();
		addVideoList();
		addMessageArea(middlePanel, " Please select a video.");
		addTransactionViewButtons();
		addCurrentLoans(null);
		addReservedVideos("empty");
		frameSize.setSize(725,330);
		this.setSize(frameSize);
		this.validate();
	}

	/*
	* Creates the transaction view panels.
	*/
	public void addTransactionWindowPanels() {
		topPanel = new Panel(new GridLayout(1,2));
		middlePanel = new Panel(new BorderLayout());
		bottomPanel = new Panel(new GridLayout(1,3));
		bottomLeftPanel = new Panel(new GridLayout(4,1));
		bottomLeftPanel.setForeground(Color.red.darker());
		bottomRightPanel = new Panel(new GridLayout(1,2));
		this.add(BorderLayout.NORTH, topPanel);
		this.add(BorderLayout.CENTER, middlePanel);
		this.add(BorderLayout.SOUTH, bottomPanel);
		bottomPanel.add(bottomLeftPanel);
		bottomPanel.add(bottomRightPanel);
	}

	/*
	* Creates the transaction view branch list and populates it
	* with the list of branches obtained from the host computer.
	* Adds the branch list to the top panel.
	*/
	public void addBranchList() {
		branchList = new List(5, false);
		branchList.setBackground(Color.yellow);
		output.println("Populate branchlist");
		try {
			while ((fromServer = input.readLine()) != null) {
				if (fromServer.equals("EndOfBranchList")) {
					break;
				}
				branchList.add(fromServer);
			}
		}
		catch(IOException ioe){
			//do nothing
		}
		topPanel.add(branchList);
		branchList.select(0);
		branchList.addItemListener(this);
	}

	/*
	* Creates the transaction view video list and populates it
	* with the list of videos held by the currently selected
	* branch. The video list is obtained from the host computer.
	* Adds the video list to the top panel.
	*/
	public void addVideoList() {
		videoList = new List(5, false);
		videoList.setBackground(Color.yellow);
		output.println("Populate videolist" + branchList.getSelectedItem());
		try {
			while ((fromServer = input.readLine()) != null) {
				if (fromServer.equals("EndOfVideoList")) {
					break;
				}
				videoList.add(fromServer);
			}
		}
		catch(IOException iExc){
			//do nothing
		}
		topPanel.add(videoList);
		videoList.validate();
		videoList.addActionListener(this);
	}

	/*
	* Creates the transaction view buttons and adds them
	* to the bottom left panel.
	*/
	public void addTransactionViewButtons() {
		previewVideoButton = new Button("Preview Selected Video");
		reserveVideoButton = new Button("Reserve Selected video");
		sendOrderButton = new Button("Send Order");
		closeTransactionViewButton = new Button("Close");
		bottomLeftPanel.add(previewVideoButton);
		bottomLeftPanel.add(reserveVideoButton);
		bottomLeftPanel.add(sendOrderButton);
		bottomLeftPanel.add(closeTransactionViewButton);
		previewVideoButton.addActionListener(this);
		reserveVideoButton.addActionListener(this);
		sendOrderButton.addActionListener(this);
		closeTransactionViewButton.addActionListener(this);
	}

	/*
	* Creates the current customer's loan list and populates it
	* with the list of videos currently on loan. The current loans
	* are obtained from the host computer.
	*
	* Adds the loan list to the bottom right panel.
	*/
	public void addCurrentLoans(String newLoans) {
		if (newLoans == null) {
			currentLoanList = new List(8, false);
			currentLoanList.setBackground(Color.yellow);
			bottomRightPanel.add(currentLoanList);
		}
		currentLoanList.removeAll();
		output.println("Populate loanlist");
		try {
			while ((fromServer = input.readLine()) != null) {
				if (fromServer.equals("EndOfLoanList")) {
					break;
				}
				currentLoanList.add(fromServer);
			}
		}
		catch(IOException iExc){
			//do nothing
		}
		currentLoanList.validate();
	}

	/*
	* Creates the current customer's reserved video list. If the
	* list already exists it will only be updated.
	*
	* The information for videos being reserved is obtained from
	* transaction view video list (none of the information is sought
	* from the host computer).
	*
	* This method also adds reserved video codes to the currentReservation
	* instance variable (reference to a Vector).
	*/
	public void addReservedVideos(String newReservation) {
		if (newReservation == "empty") {
			reservedVideoList = new List(8, false);
			reservedVideoList.setBackground(Color.yellow);
			bottomRightPanel.add(reservedVideoList);
		}
		else {
			currentReservations.addElement(newReservation);
			reservedVideoList.add(newReservation);
		}
		this.validate();
	}

	/*
	* Obtains a short preview text for the selected video from the host
	* computer and displays the preview in the transaction view message
	* area.
	*/
	public void getVideoPreview() {
		output.println("Preview video" + videoList.getSelectedItem());
		try {
			if ((fromServer = input.readLine()) != null) {
				messageArea.setText(fromServer);
			}
		}
		catch(IOException iExc){
			//do nothing
		}
	}

	/*
	* Sends a request to the host computer for a video order.
	*
	* Each order request consists of one or more video codes
	* sent in series. Appropriate transaction status messages,
	* obtained from the host computer, are displayed in the transaction
	* view message area. One message is displayed for each video loan
	* requested.
	*/
	public void sendOrder() {

		Enumeration e1 = currentReservations.elements();
		messageArea.setText(" Sending order...please wait." + '\n');
		try{
			Thread.sleep(1500);
		}
		catch(Exception e2) {
		}

		while (e1.hasMoreElements()) {
			String videoCode = (String) e1.nextElement();
			if (videoCode == null) {
				break;
			}
			output.println("Add new loan" + videoCode);
			try {
				if ((fromServer = input.readLine()) != null) {
					messageArea.append(fromServer + '\n');
				}
			}
			catch(IOException iExc){
				//do nothing
			}
		}
	}

	/*
	* Implements the abstract method supplied by
	* the ActionListener interface.
	*/
	public void actionPerformed(ActionEvent a) {

		if (!connected && a.getActionCommand().equals("<<< Connect to the server >>>")) {
			clientLogin(loginTextField.getText());
		}
		 else {
			 if (!connected && !loggedIn) {
				 clientLogin(loginTextField.getText());
			 }
		}

		if (connected && a.getActionCommand().charAt(4) == ':') {
			getVideoPreview();
		}

		if (connected && a.getActionCommand().equals("Preview Selected Video")) {
			if (videoList.getSelectedItem() != null) {
				getVideoPreview();
			}
			else {
				messageArea.setText(" Please select a video.");
			}
		}

		if (connected && a.getActionCommand().equals("Reserve Selected video")) {
			if (videoList.getSelectedItem() != null) {
				addReservedVideos(videoList.getSelectedItem());
			}
			else {
				messageArea.setText(" Please select a video.");
			}
		}

		if (connected && a.getActionCommand().equals("Send Order")) {
			if (!currentReservations.isEmpty()) {
				sendOrder();
				messageArea.setCaretPosition(0);
				addCurrentLoans("new loans");
				reservedVideoList.removeAll();
				currentReservations.removeAllElements();
				this.validate();
			}
			else {
				messageArea.setText(" Please reserve your videos before placing an order.");
			}
		}

		if (connected && a.getActionCommand().equals("Close")) {
			windowClosing(closeWindow);
		}
	}

	/*
	* Implements the abstract method supplied by
	* the ItemListener interface.
	*/
	public void itemStateChanged(ItemEvent i) {
		if (connected && i.getItemSelectable() == (branchList)) {
			topPanel.remove(videoList);
			addVideoList();
			messageArea.setText(" Please select a video.");
			this.validate();
		}
	}

	/*
	* The following methods implement the abstract methods supplied by
	* the FocusListener interface.
	*/
	public void focusGained(FocusEvent f1) {
		loginTextField.selectAll();
	}

	public void focusLost(FocusEvent f2) {
		//do nothing
	}

	/*
	* The following methods implement the abstract methods supplied by
	* the WindowListener interface.
	*/
  	public void windowClosing(WindowEvent closeWindow) {	// Close window command.
  		messageArea.setText(" Closing connection with the sever." + '\n' + '\n');
  		closeConnection();
		try{
			Thread.sleep(1000);
		}
		catch(Exception e) {
		}
  		messageArea.append(" Please call again soon!");
		try{
			Thread.sleep(2000);
		}
		catch(Exception e) {
		}
    	this.dispose();
    	System.exit(0); //the one and only normal exit point.
  	}

  	public void windowOpened(WindowEvent e) {
		//do nothing
	}

  	public void windowClosed(WindowEvent e) {
		//do nothing
	}

  	public void windowIconified(WindowEvent e) {
		//do nothing
	}

  	public void windowDeiconified(WindowEvent e) {
		//do nothing
	}

  	public void windowActivated(WindowEvent e) {
		//do nothing
	}

  	public void windowDeactivated(WindowEvent e) {
		//do nothing
	}
}