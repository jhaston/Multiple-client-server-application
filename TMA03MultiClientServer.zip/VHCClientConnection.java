/*
* J Haston, Personal Id U5032134
* VHCClientConnection.java
* M874 02E TMA03
*/

import java.net.*;
import java.io.*;

/*
* The VHCClientConnection class provides a unique communication link
* for VHCClients accessing a shared HeadOffice object simultaneously.
*
* A new instance of this class is created when the VHCMultiServer is
* started. After each successful client connection the VHCMultiServer
* creates a new socket and waits for another client connection request.
* Each new client connection request causes the VHCMultiServer to create
* a new VHCClientConnection instance.
*
* Communication between the VHCClients and the HeadOffice object is
* effected using a String-based protocol. The process
* is as follows;
*
* 1. The VHCClientConnection receives a request from a VHCClient.
* 2. The VHCClientConnection forwards the client's request to the HeadOffice.
* 3. The HeadOffice processes the request and sends a reply to
*    the VHCClientConnection.
* 4. The VHCClientConnection sends the reply to the VHCClient.
*
* Client transaction requests are only processed after a password
* has been validated.
*/
public class VHCClientConnection extends Thread {

	private Socket clientSocket = null;
	private BufferedReader input = null;
	private PrintWriter output = null;
	private String inputString;
	private String outputString;
	private Customer thisCustomer;
	private HeadOffice hd;
	private int transactionNumber = 0; //Used to provide some information
										//about the client transactions.
	//The Constructor...

	/*
	* Initialises a new instance of VHCClientConnection by creating a new
	* Thread. When an active VHCClientConnection is closed its Thread dies.
	*
	* The socket and headOffice arguments are passed from a VHCMultiServer
	* object, which creates each new instance of VHCClientConnection.
	*/
	public VHCClientConnection(Socket socket, HeadOffice headOffice) {
		super("VHCClientConnection");
		clientSocket = socket;
		hd = headOffice;
	}

	//Private Methods...

	/*
	* Validates the password supplied by the client. If the
	* password is recognised control is passed to the makeTransactions()
	* method.
	*/
	private void validatePassword() throws IOException {
		while ((inputString = input.readLine()) != null) {
			try {
				thisCustomer = hd.getCustomer(inputString);
				output.println("Login Accepted");
				System.out.println("Login accepted for " + thisCustomer + " ... waiting for transaction.");
				makeTransactions();
			}
			catch (NoSuchCustomerException nsc) {
				output.println("Login Declined");
				System.out.println("Login declined...");
			}
		}
	}

	/*
	* Provides the mechanism for communication between this
	* VHCClient and the HeadOffice object.
	*/
	/*private void makeTransactions() throws IOException {
		while ((inputString = input.readLine()) != null) {
			outputString = hd.processTransaction(thisCustomer, inputString);
			output.println(outputString);
		}
		System.out.println("Client connection closed...");
	}*/

	private void makeTransactions() throws IOException {
		while ((inputString = input.readLine()) != null) {
				//sends message to headoffice.
			outputString = hd.processTransaction(thisCustomer, inputString);
				//sends message to the client.
			output.println(outputString);
			transactionNumber ++; //this sessions transaction number
			System.out.println(thisCustomer.getAccountNum() + ": Transaction #" + transactionNumber);
		}
		System.out.println(thisCustomer.getAccountNum() + ": Connection closed...");
	}


	//Public Methods...

	/*
	* Overrides the run() method in java.lang.Thread.
	*/
	public void run() {
		openConnection();
	}

	/*
	* Creates a new BufferedReader and a new PrintWriter for this client's
	* Socket, then passes control to the validatePassword() method.
	*/
	public void openConnection() {
		try {
			input = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
			output = new PrintWriter(clientSocket.getOutputStream(), true);
			System.out.println("New client connected... verifying password.");
			validatePassword();
			//System.out.println("Client connection closed...");
		}
		catch (IOException ioe) {
			System.err.println("An IO error occurred.");
		}
	}
}