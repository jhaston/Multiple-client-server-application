/*
* J Haston, Personal Id U5032134
* VHCMultiServer.java
* M874 02E TMA03
*/

import java.net.*;
import java.io.*;

/*
* The VHCMultiServer class provides a socket for communication
* between the VHCClient and HeadOffice objects. Communication
* between these objects is effected using a String-based protocol,
* through the VHCClientConnection class.
*
* The VHCClientConnection class allows simultaneous communication
* for multiple clients. See the VHCClientConnection class for more
* detail.
*
* The VHCMultiServer class also creates a single instance of the
* HeadOffice object to be shared between all concurrent client
* instances.
*/
public class VHCMultiServer {

	private ServerSocket serverSocket = null;
	private Socket clientSocket = null;
	private boolean serverUp = true;
	private HeadOffice hd;
	private static int port;

	//The Main Method...

	/*
	* Takes an int argument for use as a Server port number and
	* creates a new VHCMultiServer instance, calling the startServer()
	* method at the same time.
	*
	* If no argument is supplied or if the argument is invalid
	* the default port number (6001) is used.
	*/
	public static void main(String args[]) throws IOException {
		try {
			port = Integer.parseInt(args[0]);
			if (!(port>1024)) {
				System.out.println("The specified port number should be greater than 1024.");
				port = 6001;
			}
		}
		catch (Exception e) {
			System.out.println("VHCMultiServer - unknown port number.");
			port = 6001;
		}
		new VHCMultiServer().startServer(port);
	}

	//The Constructor...

	/*
	* Initialises a new instance of VHCServer by creating a new
	* HeadOffice object from Serialized data located on the host
	* computer.
	*/
	private VHCMultiServer() {
		initializeHeadOffice();
	}

	//Private Methods...

	/*
	* Reads the Serialized data from the host computer to create
	* a new HeadOffice object.
	*/
	private void initializeHeadOffice() {
		hd = (new ReadHeadOffice().getCurrentData());//Read the current headOffice data.
	}

	//Public Methods...

	/*
	* Starts-up the Server and waits for a client connection request.
	* When a new connection is established the server creates a new instance
	* of VHCClientConnection to handle communication between the Client
	* and HeadOffice objects.
	*
	* This Server operates in a continuous loop, waiting for new client
	* connection requests.
	*
	* The port number is passed as an argument from the main() method.
	*/
	public void startServer(int port) throws IOException {
		System.out.println("Attempting to start server on port 6001.");

		while (serverUp) {
			try {
				serverSocket = new ServerSocket(port);
				System.out.println("Server started on port: " + port + " ... waiting for new client.");
			}
			catch (IOException e1) {
				System.err.println("Could not listen on port: " + port);
				System.exit(1);
			}
			try {
				clientSocket = serverSocket.accept();
				serverSocket.close();//prevent further log in attempts to this
										//ServerSocket instance causing server problems.
				new VHCClientConnection(clientSocket, hd).start();
				//System.out.println("New client connected...");
			}
			catch (IOException e2) {
				System.err.println("Client accept request failed.");
				try {
					serverSocket.close(); //In case the ServerSocket is still open.
				}
				catch (IOException e3) {
					//Do nothing - the ServerSocket must be closed already.
				}
			}
		}
	}
}