/*
* J Haston, Personal Id U5032134
* Video.java
* M874 02E TMA03
*/

import java.io.Serializable;

/*
* This class describes a video that might be held in stock by a video hire company.
* The Video class has private instance variables describing:
*	the video's code, a String.
*	the videos's title, a String.
*	the videos's rental cost, a String representing the rental cost in pence
*	the videos's preview text, a String, briefly describing the contents of the video.
*	the videos's current stock level, an int.
*/
public class Video implements Serializable {
	private String code;
	private String title;
	private String rentalCost;
	private String previewText;
	private int currentStockLevel;

	//The Constructor...

	/*
	* Initialises the Video code, title, rentalCost and previewText
	* instance variables with values passed as String arguments.
	* Also sets the Video's currentStockLevel variable to zero.
	*/
	public Video (String videoCode, String videoTitle, String videoRentalCost, String videoPreviewText) {
		code = videoCode;
		title = videoTitle;
		rentalCost = videoRentalCost;
		previewText = videoPreviewText;
		currentStockLevel = 0;
	}

	//Public Methods...

	/*
	* Returns the Video code String.
	*/
	public String getCode() {
		return code;
	}

	/*
	* Returns the Video title String.
	*/
	public String getTitle() {
		return title;
	}

	/*
	* Returns the Video rental cost in pence,
	* represented by a String.
	*/
	public String getRentalCost() {
		return rentalCost;
	}

	/*
	* Returns the Video preview text String.
	* Should only be used for short descriptions.
	*/
	public String getPreview() {
		return previewText;
	}

	/*
	* Returns the current stock level for the Video, an int.
	*/
	public int getNumInStock() {
		return currentStockLevel;
	}

	/*
	* Increments the Video's stock level.
	*/
	public void inc() {
		currentStockLevel++;
	}

	/*
	* Decrements the Video's stock level,
	* unless the current stock level is zero.
	*/
	public void dec() {
		if (currentStockLevel>0) currentStockLevel--;
	}

	/*
	* Returns a String representation of the Video, consisting of
	* the Video code, title, rental cost, preview text and stock level.
	*/
	public String toString() {
		return (getCode()+":"+getTitle()+":"+getRentalCost()+":"+getPreview()+":"+getNumInStock());
	}
}